# Reniec-WS
Para poder conectar a la base de datos, es necesario un archivo 'dbCredentials.properties' en la carpeta
/src/java/creds antes de compilar con la siguiente información.
```
host=
database=
port=
user=
password=
```
